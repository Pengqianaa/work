// 日期和时间显示功能
function updateDateTime() {
    const now = new Date();
    const options = { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric', 
        weekday: 'long'
    };
    const dateStr = now.toLocaleDateString('zh-CN', options);
    const timeStr = now.toLocaleTimeString('zh-CN', { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit',
        hour12: false 
    });
    
    document.getElementById('date-display').textContent = dateStr;
    document.getElementById('time-display').textContent = timeStr;
}

// 初始化日期和时间，并每秒更新一次
updateDateTime();
setInterval(updateDateTime, 1000);

// 轮播图功能
function initSlider() {
    const slider = document.getElementById('slider');
    const sliderWrapper = slider.querySelector('.slider-wrapper');
    const slides = slider.querySelectorAll('.slider-image');
    const prevBtn = slider.querySelector('#prev-btn');
    const nextBtn = slider.querySelector('#next-btn');
    const dotsContainer = slider.querySelector('#slider-dots');
    
    let currentIndex = 0;
    const slideCount = slides.length;
    
    // 创建指示点
    for (let i = 0; i < slideCount; i++) {
        const dot = document.createElement('div');
        dot.classList.add('slider-dot');
        if (i === 0) dot.classList.add('active');
        dot.addEventListener('click', () => {
            goToSlide(i);
        });
        dotsContainer.appendChild(dot);
    }
    
    const dots = dotsContainer.querySelectorAll('.slider-dot');
    
    // 更新轮播图位置
    function updateSlider() {
        sliderWrapper.style.transform = `translateX(-${currentIndex * 100}%)`;
        
        // 更新指示点状态
        dots.forEach((dot, index) => {
            if (index === currentIndex) {
                dot.classList.add('active');
            } else {
                dot.classList.remove('active');
            }
        });
    }
    
    // 切换到指定幻灯片
    function goToSlide(index) {
        currentIndex = index;
        updateSlider();
    }
    
    // 下一张幻灯片
    function nextSlide() {
        currentIndex = (currentIndex + 1) % slideCount;
        updateSlider();
    }
    
    // 上一张幻灯片
    function prevSlide() {
        currentIndex = (currentIndex - 1 + slideCount) % slideCount;
        updateSlider();
    }
    
    // 设置自动播放
    let autoplayInterval = setInterval(nextSlide, 5000);
    
    // 鼠标悬停时暂停自动播放
    slider.addEventListener('mouseenter', () => {
        clearInterval(autoplayInterval);
    });
    
    // 鼠标离开时恢复自动播放
    slider.addEventListener('mouseleave', () => {
        autoplayInterval = setInterval(nextSlide, 5000);
    });
    
    // 绑定按钮事件
    prevBtn.addEventListener('click', prevSlide);
    nextBtn.addEventListener('click', nextSlide);
    
    // 添加键盘导航
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            prevSlide();
        } else if (e.key === 'ArrowRight') {
            nextSlide();
        }
    });
}

// DOM节点操作功能
function initDOMOperations() {
    const domContainer = document.getElementById('dom-container');
    
    // 创建新节点
    document.getElementById('create-node').addEventListener('click', () => {
        const nodeName = prompt('请输入新节点的名称:');
        if (nodeName) {
            const newNode = document.createElement('div');
            newNode.className = 'dom-item';
            newNode.id = 'new-' + Date.now();
            newNode.textContent = `新节点 - ${nodeName}`;
            domContainer.appendChild(newNode);
        }
    });
    
    // 复制节点
    document.getElementById('copy-node').addEventListener('click', () => {
        const nodeId = prompt('请输入要复制的节点ID:');
        if (nodeId) {
            const node = document.getElementById(nodeId);
            if (node) {
                const clone = node.cloneNode(true);
                clone.id = clone.id + '-clone';
                domContainer.appendChild(clone);
            } else {
                alert('未找到该节点!');
            }
        }
    });
    
    // 插入节点
    document.getElementById('insert-node').addEventListener('click', () => {
        const nodeId = prompt('请输入要插入的位置节点ID:');
        const newNodeContent = prompt('请输入新节点的内容:');
        
        if (nodeId && newNodeContent) {
            const targetNode = document.getElementById(nodeId);
            if (targetNode) {
                const newNode = document.createElement('div');
                newNode.className = 'dom-item';
                newNode.id = 'inserted-' + Date.now();
                newNode.textContent = `插入的节点 - ${newNodeContent}`;
                
                targetNode.parentNode.insertBefore(newNode, targetNode.nextSibling);
            } else {
                alert('未找到该节点!');
            }
        }
    });
    
    // 替换节点
    document.getElementById('replace-node').addEventListener('click', () => {
        const nodeId = prompt('请输入要替换的节点ID:');
        const newNodeContent = prompt('请输入新节点的内容:');
        
        if (nodeId && newNodeContent) {
            const targetNode = document.getElementById(nodeId);
            if (targetNode) {
                const newNode = document.createElement('div');
                newNode.className = 'dom-item';
                newNode.id = 'replaced-' + Date.now();
                newNode.textContent = `替换的节点 - ${newNodeContent}`;
                
                targetNode.parentNode.replaceChild(newNode, targetNode);
            } else {
                alert('未找到该节点!');
            }
        }
    });
    
    // 删除节点
    document.getElementById('delete-node').addEventListener('click', () => {
        const nodeId = prompt('请输入要删除的节点ID:');
        if (nodeId) {
            if (confirm(`确定要删除节点 ${nodeId} 吗?`)) {
                const node = document.getElementById(nodeId);
                if (node) {
                    node.parentNode.removeChild(node);
                } else {
                    alert('未找到该节点!');
                }
            }
        }
    });
}

// jQuery选项卡功能
function initTabs() {
    const tabs = $('#tabs');
    const tabItems = tabs.find('.tab-item');
    const tabPanes = tabs.find('.tab-pane');
    
    // 初始化选项卡
    tabItems.click(function() {
        const tabId = $(this).attr('data-tab');
        
        // 更新选项卡样式
        tabItems.removeClass('active');
        $(this).addClass('active');
        
        // 显示对应内容
        tabPanes.hide();
        $('#' + tabId).show();
    });
    
    // 调整大小按钮
    $('#resize-tab').click(function() {
        const tabContent = tabs.find('.tab-content');
        const currentWidth = tabContent.width();
        tabContent.width(currentWidth * 1.1);
    });
    
    // 移动位置按钮
    $('#move-tab').click(function() {
        const tabContent = tabs.find('.tab-content');
        const currentTop = parseInt(tabContent.css('top') || 0);
        tabContent.css('position', 'relative');
        tabContent.css('top', currentTop + 10 + 'px');
    });
    
    // 调整顺序按钮
    $('#reorder-tab').click(function() {
        const tabNav = tabs.find('.tab-nav');
        const items = tabNav.find('.tab-item');
        items.sort(function() {
            return 0.5 - Math.random();
        });
        tabNav.empty().append(items);
    });
    
    // 随机效果按钮
    $('#random-effect').click(function() {
        const activePane = tabs.find('.tab-pane.active');
        const randomColor = '#' + Math.floor(Math.random()*16777215).toString(16);
        const randomSize = Math.floor(Math.random() * 20 + 12) + 'px';
        const randomOpacity = Math.random() * 0.5 + 0.5;
        
        activePane.find('p').css({
            'color': randomColor,
            'font-size': randomSize
        });
        
        activePane.find('img').css({
            'opacity': randomOpacity,
            'border-radius': Math.floor(Math.random() * 50) + 'px'
        });
    });
}

// 表单验证功能
function initFormValidation() {
    const form = document.getElementById('registration-form');
    const resultContent = document.getElementById('result-content');
    const submissionResult = document.getElementById('submission-result');
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        let isValid = true;
        
        // 验证用户名
        const username = document.getElementById('username');
        const usernameError = document.getElementById('username-error');
        if (!username.value.trim()) {
            usernameError.textContent = '用户名不能为空';
            isValid = false;
        } else if (username.value.length < 3) {
            usernameError.textContent = '用户名至少需要3个字符';
            isValid = false;
        } else {
            usernameError.textContent = '';
        }
        
        // 验证邮箱
        const email = document.getElementById('email');
        const emailError = document.getElementById('email-error');
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!email.value.trim()) {
            emailError.textContent = '邮箱不能为空';
            isValid = false;
        } else if (!emailRegex.test(email.value)) {
            emailError.textContent = '请输入有效的邮箱地址';
            isValid = false;
        } else {
            emailError.textContent = '';
        }
        
        // 验证密码
        const password = document.getElementById('password');
        const passwordError = document.getElementById('password-error');
        if (!password.value.trim()) {
            passwordError.textContent = '密码不能为空';
            isValid = false;
        } else if (password.value.length < 6) {
            passwordError.textContent = '密码至少需要6个字符';
            isValid = false;
        } else {
            passwordError.textContent = '';
        }
        
        // 验证确认密码
        const confirmPassword = document.getElementById('confirm-password');
        const confirmPasswordError = document.getElementById('confirm-password-error');
        if (!confirmPassword.value.trim()) {
            confirmPasswordError.textContent = '请确认密码';
            isValid = false;
        } else if (confirmPassword.value !== password.value) {
            confirmPasswordError.textContent = '两次输入的密码不一致';
            isValid = false;
        } else {
            confirmPasswordError.textContent = '';
        }
        
        // 验证验证码
        const captcha = document.getElementById('captcha');
        const captchaError = document.getElementById('captcha-error');
        if (!captcha.value.trim()) {
            captchaError.textContent = '请输入验证码';
            isValid = false;
        } else if (captcha.value !== '8aB4') {
            captchaError.textContent = '验证码不正确';
            isValid = false;
        } else {
            captchaError.textContent = '';
        }
        
        // 验证同意条款
        const terms = document.getElementById('terms');
        const termsError = document.getElementById('terms-error');
        if (!terms.checked) {
            termsError.textContent = '请同意服务条款和隐私政策';
            isValid = false;
        } else {
            termsError.textContent = '';
        }
        
        // 如果表单验证通过，显示提交结果
        if (isValid) {
            // 收集表单数据
            const formData = {
                username: username.value,
                email: email.value,
                birthdate: document.getElementById('birthdate').value,
                gender: document.querySelector('input[name="gender"]:checked')?.value || '未选择',
                country: document.getElementById('country').value,
                message: document.getElementById('message').value
            };
            
            // 构建结果消息
            let message = '表单提交成功！\n\n';
            for (const [key, value] of Object.entries(formData)) {
                message += `${key}: ${value}\n`;
            }
            
            // 显示结果
            document.getElementById('result-message').textContent = message;
            submissionResult.classList.remove('hidden');
            
            // 添加动画效果
            setTimeout(() => {
                resultContent.classList.remove('scale-95', 'opacity-0');
                resultContent.classList.add('scale-100', 'opacity-100');
            }, 10);
            
            // 重置表单
            form.reset();
        }
    });
    
    // 关闭结果模态框
    document.getElementById('close-result').addEventListener('click', () => {
        resultContent.classList.remove('scale-100', 'opacity-100');
        resultContent.classList.add('scale-95', 'opacity-0');
        
        setTimeout(() => {
            submissionResult.classList.add('hidden');
        }, 300);
    });
}

// 初始化所有功能
document.addEventListener('DOMContentLoaded', function() {
    initSlider();
    initDOMOperations();
    initFormValidation();
    
    // jQuery相关初始化
    $(document).ready(function() {
        initTabs();
        
        // 移动菜单功能
        $('.mobile-menu-toggle').click(function() {
            $('nav ul').toggleClass('active');
        });
        
        // FAQ折叠功能
        $('.faq-item h4').click(function() {
            $(this).parent().toggleClass('active');
            $(this).find('i').toggleClass('rotate-180');
        });
        
        // 导航栏滚动效果
        $(window).scroll(function() {
            const header = $('#main-header');
            if ($(this).scrollTop() > 50) {
                header.addClass('py-2 shadow-lg');
                header.removeClass('py-3 shadow-md');
            } else {
                header.addClass('py-3 shadow-md');
                header.removeClass('py-2 shadow-lg');
            }
        });
    });
}); 