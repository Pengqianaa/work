// 日期和时间显示功能
function updateDateTime() {
    const dateDisplay = document.getElementById('date-display');
    const timeDisplay = document.getElementById('time-display');
    
    // 如果元素不存在，直接返回
    if (!dateDisplay || !timeDisplay) return;
    
    const now = new Date();
    const dateOptions = { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric', 
        weekday: 'long'
    };
    const timeOptions = { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit',
        hour12: false 
    };
    
    dateDisplay.textContent = now.toLocaleDateString('zh-CN', dateOptions);
    timeDisplay.textContent = now.toLocaleTimeString('zh-CN', timeOptions);
}

// 只有在找到相关元素时才初始化日期时间显示
if (document.getElementById('date-display') && document.getElementById('time-display')) {
    updateDateTime();
    setInterval(updateDateTime, 1000);
}

// 轮播图功能
function initSlider() {
    const slider = document.getElementById('slider');
    if (!slider) return;

    const slides = slider.querySelectorAll('.slider-image');
    const prevBtn = slider.querySelector('#prev-btn');
    const nextBtn = slider.querySelector('#next-btn');
    const dotsContainer = slider.querySelector('#slider-dots');
    
    let currentIndex = 0;
    const slideCount = slides.length;
    
    // 初始化第一张图片
    slides[0].classList.add('active');
    
    // 创建指示点
    dotsContainer.innerHTML = '';
    for (let i = 0; i < slideCount; i++) {
        const dot = document.createElement('div');
        dot.classList.add('slider-dot');
        if (i === 0) dot.classList.add('active');
        dot.addEventListener('click', () => goToSlide(i));
        dotsContainer.appendChild(dot);
    }
    
    const dots = dotsContainer.querySelectorAll('.slider-dot');
    
    function updateSlider() {
        // 更新幻灯片显示
        slides.forEach((slide, index) => {
            slide.classList.toggle('active', index === currentIndex);
        });
        
        // 更新指示点
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentIndex);
        });
    }
    
    function goToSlide(index) {
        currentIndex = index;
        updateSlider();
    }
    
    function nextSlide() {
        currentIndex = (currentIndex + 1) % slideCount;
        updateSlider();
    }
    
    function prevSlide() {
        currentIndex = (currentIndex - 1 + slideCount) % slideCount;
        updateSlider();
    }
    
    // 绑定按钮事件
    prevBtn?.addEventListener('click', () => {
        prevSlide();
        resetAutoplay();
    });
    
    nextBtn?.addEventListener('click', () => {
        nextSlide();
        resetAutoplay();
    });
    
    // 自动播放
    let autoplayTimer = null;
    
    function startAutoplay() {
        stopAutoplay();
        autoplayTimer = setInterval(nextSlide, 5000);
    }
    
    function stopAutoplay() {
        if (autoplayTimer) {
            clearInterval(autoplayTimer);
            autoplayTimer = null;
        }
    }
    
    function resetAutoplay() {
        stopAutoplay();
        startAutoplay();
    }
    
    // 鼠标悬停控制
    slider.addEventListener('mouseenter', stopAutoplay);
    slider.addEventListener('mouseleave', startAutoplay);
    
    // 启动自动播放
    startAutoplay();
}

// DOM节点操作功能
function initDOMOperations() {
    const domContainer = document.getElementById('dom-container');
    const createBtn = document.getElementById('create-node');
    const copyBtn = document.getElementById('copy-node');
    const insertBtn = document.getElementById('insert-node');
    const replaceBtn = document.getElementById('replace-node');
    const deleteBtn = document.getElementById('delete-node');
    
    // 如果不是DOM操作相关页面，直接返回
    if (!domContainer || !createBtn) return;

    // 创建新节点
    createBtn.addEventListener('click', () => {
        const nodeName = prompt('请输入新节点的名称:');
        if (nodeName) {
            const newNode = document.createElement('div');
            newNode.className = 'dom-item';
            newNode.id = 'new-' + Date.now();
            newNode.textContent = `新节点 - ${nodeName}`;
            domContainer.appendChild(newNode);
        }
    });
    
    // 复制节点
    copyBtn.addEventListener('click', () => {
        const nodeId = prompt('请输入要复制的节点ID:');
        if (nodeId) {
            const node = document.getElementById(nodeId);
            if (node) {
                const clone = node.cloneNode(true);
                clone.id = clone.id + '-clone';
                domContainer.appendChild(clone);
            } else {
                alert('未找到该节点!');
            }
        }
    });
    
    // 插入节点
    insertBtn.addEventListener('click', () => {
        const nodeId = prompt('请输入要插入的位置节点ID:');
        const newNodeContent = prompt('请输入新节点的内容:');
        
        if (nodeId && newNodeContent) {
            const targetNode = document.getElementById(nodeId);
            if (targetNode) {
                const newNode = document.createElement('div');
                newNode.className = 'dom-item';
                newNode.id = 'inserted-' + Date.now();
                newNode.textContent = `插入的节点 - ${newNodeContent}`;
                
                targetNode.parentNode.insertBefore(newNode, targetNode.nextSibling);
            } else {
                alert('未找到该节点!');
            }
        }
    });
    
    // 替换节点
    replaceBtn.addEventListener('click', () => {
        const nodeId = prompt('请输入要替换的节点ID:');
        const newNodeContent = prompt('请输入新节点的内容:');
        
        if (nodeId && newNodeContent) {
            const targetNode = document.getElementById(nodeId);
            if (targetNode) {
                const newNode = document.createElement('div');
                newNode.className = 'dom-item';
                newNode.id = 'replaced-' + Date.now();
                newNode.textContent = `替换的节点 - ${newNodeContent}`;
                
                targetNode.parentNode.replaceChild(newNode, targetNode);
            } else {
                alert('未找到该节点!');
            }
        }
    });
    
    // 删除节点
    deleteBtn.addEventListener('click', () => {
        const nodeId = prompt('请输入要删除的节点ID:');
        if (nodeId) {
            if (confirm(`确定要删除节点 ${nodeId} 吗?`)) {
                const node = document.getElementById(nodeId);
                if (node) {
                    node.parentNode.removeChild(node);
                } else {
                    alert('未找到该节点!');
                }
            }
        }
    });
}

// jQuery选项卡功能
function initTabs() {
    const tabs = $('#tabs');
    const tabItems = tabs.find('.tab-item');
    const tabPanes = tabs.find('.tab-pane');
    
    // 初始化选项卡
    tabItems.click(function() {
        const tabId = $(this).attr('data-tab');
        
        // 更新选项卡样式
        tabItems.removeClass('active');
        $(this).addClass('active');
        
        // 显示对应内容
        tabPanes.hide();
        $('#' + tabId).show();
    });
    
    // 调整大小按钮
    $('#resize-tab').click(function() {
        const tabContent = tabs.find('.tab-content');
        const currentWidth = tabContent.width();
        tabContent.width(currentWidth * 1.1);
    });
    
    // 移动位置按钮
    $('#move-tab').click(function() {
        const tabContent = tabs.find('.tab-content');
        const currentTop = parseInt(tabContent.css('top') || 0);
        tabContent.css('position', 'relative');
        tabContent.css('top', currentTop + 10 + 'px');
    });
    
    // 调整顺序按钮
    $('#reorder-tab').click(function() {
        const tabNav = tabs.find('.tab-nav');
        const items = tabNav.find('.tab-item');
        items.sort(function() {
            return 0.5 - Math.random();
        });
        tabNav.empty().append(items);
    });
    
    // 随机效果按钮
    $('#random-effect').click(function() {
        const activePane = tabs.find('.tab-pane.active');
        const randomColor = '#' + Math.floor(Math.random()*16777215).toString(16);
        const randomSize = Math.floor(Math.random() * 20 + 12) + 'px';
        const randomOpacity = Math.random() * 0.5 + 0.5;
        
        activePane.find('p').css({
            'color': randomColor,
            'font-size': randomSize
        });
        
        activePane.find('img').css({
            'opacity': randomOpacity,
            'border-radius': Math.floor(Math.random() * 50) + 'px'
        });
    });
}

// 表单验证功能
function initFormValidation() {
    const form = document.getElementById('registration-form');
    
    if (!form) return;

    const submissionResult = document.getElementById('submission-result');
    const resultContent = document.getElementById('result-content');
    
    form.addEventListener('submit', function(e) {
        e.stopPropagation();        
        e.preventDefault();
        let isValid = true;
        
        // 验证用户名
        const username = document.getElementById('username');
        const usernameError = document.getElementById('username-error');
        if (!username.value.trim()) {
            usernameError.textContent = '用户名不能为空';
            isValid = false;
            errorFields.push(username);
        } else if (username.value.length < 3) {
            usernameError.textContent = '用户名至少需要3个字符';
            isValid = false;
            errorFields.push(username);
        } else {
            usernameError.textContent = '';
        }
        
        // 验证邮箱
        const email = document.getElementById('email');
        const emailError = document.getElementById('email-error');
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!email.value.trim()) {
            emailError.textContent = '邮箱不能为空';
            isValid = false;
            errorFields.push(email);
        } else if (!emailRegex.test(email.value)) {
            emailError.textContent = '请输入有效的邮箱地址';
            isValid = false;
            errorFields.push(email);
        } else {
            emailError.textContent = '';
        }
        
        // 验证密码
        const password = document.getElementById('password');
        const passwordError = document.getElementById('password-error');
        if (!password.value.trim()) {
            passwordError.textContent = '密码不能为空';
            isValid = false;
            errorFields.push(password);
        } else if (password.value.length < 6) {
            passwordError.textContent = '密码至少需要6个字符';
            isValid = false;
            errorFields.push(password);
        } else {
            passwordError.textContent = '';
        }
        
        // 验证确认密码
        const confirmPassword = document.getElementById('confirm-password');
        const confirmPasswordError = document.getElementById('confirm-password-error');
        if (!confirmPassword.value.trim()) {
            confirmPasswordError.textContent = '请确认密码';
            isValid = false;
            errorFields.push(confirmPassword);
        } else if (confirmPassword.value !== password.value) {
            confirmPasswordError.textContent = '两次输入的密码不一致';
            isValid = false;
            errorFields.push(confirmPassword);
        } else {
            confirmPasswordError.textContent = '';
        }
        
        // 验证验证码
        const captcha = document.getElementById('captcha');
        const captchaError = document.getElementById('captcha-error');
        if (!captcha.value.trim()) {
            captchaError.textContent = '请输入验证码';
            isValid = false;
            errorFields.push(captcha);
        } else if (captcha.value !== '8aB4') {
            captchaError.textContent = '验证码不正确';
            isValid = false;
            errorFields.push(captcha);
        } else {
            captchaError.textContent = '';
        }
        
        // 验证同意条款
        const terms = document.getElementById('terms');
        const termsError = document.getElementById('terms-error');
        if (!terms.checked) {
            termsError.textContent = '请同意服务条款和隐私政策';
            isValid = false;
            errorFields.push(terms);
        } else {
            termsError.textContent = '';
        }
        
        // 如果表单验证通过，显示提交结果
        if (isValid) {
            // 收集表单数据
            const formData = {
                username: username.value,
                email: email.value,
                birthdate: document.getElementById('birthdate')?.value || '',
                gender: document.querySelector('input[name="gender"]:checked')?.value || '未选择',
                country: document.getElementById('country')?.value || '',
                message: document.getElementById('message')?.value || ''
            };
            
            // 更新结果消息并显示模态框
            document.getElementById('result-message').innerHTML = `
                <div class="text-left space-y-2">
                    <p><span class="font-medium">用户名：</span>${formData.username}</p>
                    <p><span class="font-medium">邮箱：</span>${formData.email}</p>
                    <p><span class="font-medium">出生日期：</span>${formData.birthdate}</p>
                    <p><span class="font-medium">性别：</span>${formData.gender}</p>
                    <p><span class="font-medium">国家/地区：</span>${formData.country}</p>
                    <p><span class="font-medium">留言：</span>${formData.message}</p>
                </div>
            `;
            
            // 显示模态框
            submissionResult.classList.remove('hidden');
            setTimeout(() => {
                submissionResult.classList.add('active');
            }, 10);
            
            // 重置表单
            form.reset();
        }
    });
    
    // 关闭结果模态框
    const closeButton = document.getElementById('close-result');
    if (closeButton) {
        closeButton.addEventListener('click', () => {
            submissionResult.classList.remove('active');
            setTimeout(() => {
                submissionResult.classList.add('hidden');
            }, 300);
        });
    }
    
    // 点击背景关闭模态框
    submissionResult?.addEventListener('click', (e) => {
        if (e.target === submissionResult) {
            closeButton.click();
        }
    });
}

// 初始化所有功能
document.addEventListener('DOMContentLoaded', function() {
    // 根据页面元素选择性初始化功能
    const slider = document.getElementById('slider');
    const domContainer = document.getElementById('dom-container');
    const registrationForm = document.getElementById('registration-form');
    const tabs = document.getElementById('tabs');
    
    if (slider) initSlider();
    if (domContainer) initDOMOperations();
    if (registrationForm) initFormValidation();
    if (tabs) initTabs();
    
    // jQuery相关初始化
    $(document).ready(function() {
        // 移动菜单功能
        $('.mobile-menu-toggle').click(function() {
            $('nav ul').toggleClass('active');
        });
        
        // FAQ折叠功能
        $('.faq-item h4').click(function() {
            const item = $(this).parent();
            const content = item.find('.faq-content');
            const icon = $(this).find('i');
            
            // 如果当前项已经是展开状态，则关闭它
            if (item.hasClass('active')) {
                item.removeClass('active');
                icon.removeClass('rotate-180');
            } else {
                // 先关闭其他所有项
                $('.faq-item').removeClass('active');
                $('.faq-item i').removeClass('rotate-180');
                // 展开当前项
                item.addClass('active');
                icon.addClass('rotate-180');
            }
        });
        
        // 导航栏滚动效果
        $(window).scroll(function() {
            const header = $('#main-header');
            if ($(this).scrollTop() > 50) {
                header.addClass('py-2 shadow-lg');
                header.removeClass('py-3 shadow-md');
            } else {
                header.addClass('py-3 shadow-md');
                header.removeClass('py-2 shadow-lg');
            }
        });
    });
    
    // 修改导航链接处理
    document.querySelectorAll('nav a').forEach(link => {
        link.addEventListener('click', function(e) {
            // 如果是哈希链接，不阻止默认行为
            if (this.getAttribute('href').startsWith('#')) {
                return;
            }
            e.preventDefault();
            const href = this.getAttribute('href');
            // 直接进行页面跳转
            window.location.href = href;
        });
    });
});

